import React from "react";
const NotFound = () => {
  return (
    <div>
      <h1>Page Not Founds</h1>
    </div>
  );
};

export default NotFound;
